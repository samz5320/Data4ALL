======================================================================
David W. Aha
9/27/88 
Comments on the Mushroom Database
======================================================================

I've replaced the original database twice.  
   1. The database was lost due to backup/downtime problems here at
      UCI.  I replaced the database with a version given to me by
      Wayne Iba.  A brief check indicated that it was in good shape.
   2. Jeff Schlimmer, donater of the database, recently mailed me a
      copy of the database, with suitable 1-character acronymns for
      attribute values (the size of the compressed database shrinks
      from 120 to 50k).  

I suspect that several people have had trouble copying the database over
to their locations.  Please let me know if there is any problem in the 
future.

Thanks,
    Dave Aha
